package be.uantwerpen.idlab.cobra.blockgen.models.xml;

/**
 * Created by Thomas on 1/12/2016.
 */
public interface XMLObject
{
    String getXMLString();
}

package be.uantwerpen.idlab.cobra.blockgen.tools.terminal;

/**
 * Created by Thomas on 17/11/2016.
 */
public enum NotificationLevel
{
    ALL_NOTIFICATIONS,
    WARNING_NOTIFICATIONS,
    ERROR_NOTIFICATIONS
}

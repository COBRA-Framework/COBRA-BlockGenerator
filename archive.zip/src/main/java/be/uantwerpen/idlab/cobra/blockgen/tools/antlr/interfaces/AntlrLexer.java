package be.uantwerpen.idlab.cobra.blockgen.tools.antlr.interfaces;

import org.antlr.v4.runtime.TokenSource;

/**
 * Created by Thomas on 20/03/2016.
 */
public interface AntlrLexer extends TokenSource
{

}

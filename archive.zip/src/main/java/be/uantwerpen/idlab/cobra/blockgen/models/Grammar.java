package be.uantwerpen.idlab.cobra.blockgen.models;

/**
 * Created by Thomas on 7/12/2016.
 */
public enum Grammar
{
    C,
    CPP,
    UNKNOWN
}

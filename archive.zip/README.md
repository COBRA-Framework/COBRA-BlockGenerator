# COBRA-BlockGenerator

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/960eeb00a9e14e238eb7fe6120036961)](https://www.codacy.com/app/MOSAIC/COBRA-BlockGenerator?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=COBRA-Framework/COBRA-BlockGenerator&amp;utm_campaign=Badge_Grade)
[![Build Status](http://143.129.39.111:8111/app/rest/builds/buildType:id:COBRA_BlockGenerator_ReleaseBuild/statusIcon)](http://143.129.39.111:8111/viewType.html?buildTypeId=COBRA_BlockGenerator_ReleaseBuild&guest=1)
